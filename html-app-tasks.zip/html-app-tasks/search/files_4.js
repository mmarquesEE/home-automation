var searchData=
[
  ['sensor_5ftask_2ec_0',['sensor_task.c',['../sensor__task_8c.html',1,'']]]
];

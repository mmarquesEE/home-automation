var searchData=
[
  ['sensor_5fqueue_0',['sensor_queue',['../display__task_8c.html#a8ef6c7739752ee9ab50848e42272f87c',1,'sensor_queue:&#160;display_task.c'],['../mqtt__task_8c.html#a8ef6c7739752ee9ab50848e42272f87c',1,'sensor_queue:&#160;mqtt_task.c'],['../sensor__task_8c.html#a8ef6c7739752ee9ab50848e42272f87c',1,'sensor_queue:&#160;sensor_task.c']]],
  ['sensor_5ftask_1',['sensor_task',['../sensor__task_8c.html#a6493752ed974091bf79fd62d469ee392',1,'sensor_task.c']]],
  ['sensor_5ftask_2ec_2',['sensor_task.c',['../sensor__task_8c.html',1,'']]]
];

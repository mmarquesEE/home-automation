var searchData=
[
  ['sensor_5ftask_0',['sensor_task',['../sensor__task_8c.html#a6493752ed974091bf79fd62d469ee392',1,'sensor_task.c']]]
];

var searchData=
[
  ['time_5fqueue_0',['time_queue',['../display__task_8c.html#a5816cdfd73f65a8a0b00586ca058b03d',1,'time_queue:&#160;display_task.c'],['../mqtt__task_8c.html#a5816cdfd73f65a8a0b00586ca058b03d',1,'time_queue:&#160;mqtt_task.c']]]
];

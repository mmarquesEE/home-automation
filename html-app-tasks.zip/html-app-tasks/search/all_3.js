var searchData=
[
  ['i2c_5fmaster_5fnum_0',['I2C_MASTER_NUM',['../display__task_8c.html#aab9e642b6200f95fcbd2ad7466aaa2d3',1,'display_task.c']]],
  ['i2c_5fmaster_5fscl_5fio_1',['I2C_MASTER_SCL_IO',['../display__task_8c.html#a033b5e8a30541fe4ff939a62fdb7a43d',1,'display_task.c']]],
  ['i2c_5fmaster_5fsda_5fio_2',['I2C_MASTER_SDA_IO',['../display__task_8c.html#af47631d568bba17edf9d1ea042602bb6',1,'display_task.c']]]
];

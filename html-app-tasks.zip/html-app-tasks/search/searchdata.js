var indexSectionsWithContent =
{
  0: "bdeilmst",
  1: "bdlms",
  2: "bdlms",
  3: "lst",
  4: "beil"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables",
  4: "Macros"
};

